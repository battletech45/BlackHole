package com.example.black_hole

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
